package merousha.com.instagramclone2.Utils;

/**
 * Created by Vanil-Singh on 10/13/2017.
 */

public class ViewLocationFragment {
}
