# Instagram-Clone
I have created an instagram clone based of firebase
